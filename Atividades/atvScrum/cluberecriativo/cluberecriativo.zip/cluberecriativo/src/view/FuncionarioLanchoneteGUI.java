package view;

import javax.swing.*;
import model.Funcionario;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FuncionarioLanchoneteGUI extends JFrame {
    
	private static final long serialVersionUID = -5053575192432548710L;
	private Funcionario funcionario;

    public FuncionarioLanchoneteGUI() {
    	
        // Configurações da janela
        setTitle("Menu de Funcionário da Lanchonete");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout principal
        setLayout(new GridLayout(4, 1));

        // Botão para registrar consumo na lanchonete
        JButton registrarConsumoButton = new JButton("Registrar consumo na lanchonete");
        registrarConsumoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Registrar consumo na lanchonete selecionado");
            }
        });
        add(registrarConsumoButton);

        // Botão para visualizar registros de consumo na lanchonete
        JButton visualizarRegistrosButton = new JButton("Visualizar registros de consumo na lanchonete");
        visualizarRegistrosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Visualizar registros de consumo na lanchonete selecionado");
            }
        });
        add(visualizarRegistrosButton);

        // Botão para configurar notificações
        JButton configurarNotificacoesButton = new JButton("Configurar notificações");
        configurarNotificacoesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Configurar notificações selecionado");
            }
        });
        add(configurarNotificacoesButton);

        // Botão para voltar ao menu anterior
        JButton voltarButton = new JButton("Voltar ao menu anterior");
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();  // Fecha a janela atual
                // Adicione aqui a lógica para voltar ao menu anterior
            }
        });
        add(voltarButton);
    }
    
    public void exibir() {
    	setVisible(true);
    }

    public static void main(String[] args) {
        // Exemplo de uso
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FuncionarioLanchoneteGUI().exibir();
            }
        });
    }
}
