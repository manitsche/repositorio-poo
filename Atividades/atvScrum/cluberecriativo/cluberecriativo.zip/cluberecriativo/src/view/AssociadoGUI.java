package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AssociadoGUI extends JFrame {

	private static final long serialVersionUID = 4320574710332177202L;

	public AssociadoGUI() {
        // Configurações da janela do associado
        setTitle("Menu do Associado");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout principal
        setLayout(new GridLayout(3, 1));

        // Botão para visualizar atividades cadastradas
        JButton atividadesButton = new JButton("Visualizar atividades cadastradas");
        atividadesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Visualizar atividades cadastradas selecionado");
            }
        });
        add(atividadesButton);

        // Botão para visualizar número de faltas
        JButton faltasButton = new JButton("Visualizar número de faltas");
        faltasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Visualizar número de faltas selecionado");
            }
        });
        add(faltasButton);

        // Botão para voltar ao menu anterior
        JButton voltarButton = new JButton("Voltar ao menu anterior");
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(voltarButton);
    }

    public void exibir() {
        setVisible(true);
    }
}