package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import model.Atividade;
import model.Funcionario;

public class CadastroAtividadeGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private List<Atividade> listaAtividades;
    private List<Funcionario> listaFuncionarios;

    public CadastroAtividadeGUI(List<Atividade> listaAtividades) {
        this.listaAtividades = listaAtividades;

        // Configurações da janela
        setTitle("Cadastro de Atividade");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Layout principal
        setLayout(new GridLayout(8, 2));

        // Campos de texto
        add(new JLabel("Nome da atividade:"));
        JTextField nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Descrição da atividade:"));
        JTextField descricaoField = new JTextField();
        add(descricaoField);

        add(new JLabel("Faixa etária:"));
        JTextField faixaEtariaField = new JTextField();
        add(faixaEtariaField);

        add(new JLabel("Restrições:"));
        JTextField restricoesField = new JTextField();
        add(restricoesField);

        add(new JLabel("Turma:"));
        JTextField turmaField = new JTextField();
        add(turmaField);

        add(new JLabel("Horário:"));
        JTextField horarioField = new JTextField();
        add(horarioField);

        add(new JLabel("Instrutor:"));
        JTextField instrutorField = new JTextField();
        add(instrutorField);

        // Botão para cadastrar atividade
        JButton cadastrarButton = new JButton("Cadastrar Atividade");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarAtividade(nomeField.getText(), descricaoField.getText(), faixaEtariaField.getText(),
                        restricoesField.getText(), turmaField.getText(), horarioField.getText(),
                        instrutorField.getText());

                // Limpar campos após o cadastro
                nomeField.setText("");
                descricaoField.setText("");
                faixaEtariaField.setText("");
                restricoesField.setText("");
                turmaField.setText("");
                horarioField.setText("");
                instrutorField.setText("");
            }
        });
        add(cadastrarButton);

        // Botão para fechar a janela
        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarAtividade(String nome, String descricao, String faixaEtaria, String restricoes, String turma, String horario, String instrutor) {
        int nextId = 1;
        if (!listaAtividades.isEmpty()) {
            nextId = listaAtividades.get(listaAtividades.size() - 1).getIdatividade() + 1;
        }

        Atividade novaAtividade = new Atividade(nome, descricao, faixaEtaria, restricoes, turma, horario, instrutor);
        listaAtividades.add(novaAtividade);
        JOptionPane.showMessageDialog(null, "Atividade cadastrada com sucesso!");
        voltarAoMenuGerente();
    }

    public void exibir() {
        setVisible(true);
    }
    
    private static List<Atividade> criarListaAtividades() {
        List<Atividade> listaAtividades = new ArrayList<>();

        Atividade atividade1 = new Atividade("Natacao", "Natacao para todos", "3 a 65 anos", "Todos", "Turma 1", "07 as 08, | 14 as 15 | 18 as 19", "Professora Flavia");
        listaAtividades.add(0, atividade1);
        
        return listaAtividades;
    }
    
    private void voltarAoMenuGerente() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
				new GerenteGUI(listaFuncionarios).exibir();
            }
        });
    }
    
}