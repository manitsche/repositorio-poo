package view;

import javax.swing.*;

import dao.ConexaoBD;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import model.Associado;
import model.Atividade;
import model.Funcionario;
import model.Gerente;

public class MainGUI extends JFrame {

    private static final long serialVersionUID = -3111640726945795981L;
    private List<Associado> listaAssociados;
    private List<Funcionario> listaFuncionarios;
    private List<Gerente> listaGerentes;
    private List<Atividade> listaAtividades;
    private ConexaoBD conexaoBD;

    public MainGUI(List<Associado> listaAssociados, List<Funcionario> listaFuncionarios, List<Gerente> listaGerentes,
            List<Atividade> listaAtividades, ConexaoBD conexaoBD) {
        this.listaAssociados = listaAssociados;
        this.listaFuncionarios = listaFuncionarios;
        this.listaGerentes = listaGerentes;
        this.listaAtividades = listaAtividades;
        this.conexaoBD = conexaoBD;

        // Configurações da janela
        setTitle("Menu Inicial");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Layout principal
        setLayout(new GridLayout(4, 1));

        // Botão para login como associado
        JButton loginAssociadoButton = new JButton("Login como associado");
        loginAssociadoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                autenticarAssociado();
            }
        });
        add(loginAssociadoButton);

        JButton loginFuncionarioButton = new JButton("Login como funcionário");
        loginFuncionarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                autenticarFuncionario();
            }
        });
        add(loginFuncionarioButton);

        JButton loginGerenteButton = new JButton("Login como gerente");
        loginGerenteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                autenticarGerente();
            }
        });
        add(loginGerenteButton);

        JButton sairButton = new JButton("Sair");
        sairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                encerrarPrograma();
            }
        });
        add(sairButton);
    }

    private void autenticarAssociado() {
        // Lógica de autenticação do associado
        String loginAssociado = JOptionPane.showInputDialog("Digite seu login como associado:");
        String senhaAssociado = JOptionPane.showInputDialog("Digite sua senha como associado:");

        Associado associadoAutenticado = null;

        for (Associado associado : listaAssociados) {
            if (associado.getLogin().equals(loginAssociado) && associado.getSenha().equals(senhaAssociado)) {
                associadoAutenticado = associado;
                break;
            }
        }

        if (associadoAutenticado != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new AssociadoGUI().exibir();
                }
            });
        } else {
            JOptionPane.showMessageDialog(null, "Login ou senha de associado incorretos. Acesso negado.");
        }
    }

    private void autenticarFuncionario() {
        // Lógica de autenticação do funcionário
        String loginFuncionario = JOptionPane.showInputDialog("Digite seu login como funcionário:");
        String senhaFuncionario = JOptionPane.showInputDialog("Digite sua senha como funcionário:");

        Funcionario funcionarioAutenticado = null;

        for (Funcionario funcionario : listaFuncionarios) {
            if (funcionario.getLogin().equals(loginFuncionario) && funcionario.getSenha().equals(senhaFuncionario)) {
                funcionarioAutenticado = funcionario;
                break;
            }
        }

        if (funcionarioAutenticado != null) {
            if ("Lanchonete".equals(funcionarioAutenticado.getCargo())) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        new FuncionarioLanchoneteGUI().exibir();
                    }
                });
            } else {
                exibirFuncionarioGUI(listaAssociados, listaAtividades);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Login ou senha de funcionário incorretos. Acesso negado.");
        }
    }

    private void exibirFuncionarioGUI(List<Associado> listaAssociados, List<Atividade> listaAtividades) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                FuncionarioGUI funcionarioGui = new FuncionarioGUI(listaAssociados, listaAtividades);
                funcionarioGui.exibir();
            }
        });
    }

    private void autenticarGerente() {
        // Lógica de autenticação do associado
        String loginGerente = JOptionPane.showInputDialog("Digite seu login como gerente:");
        String senhaGerente = JOptionPane.showInputDialog("Digite sua senha como gerente:");

        Gerente gerenteAutenticado = null;

        for (Gerente gerente : listaGerentes) {
            if (gerente.getLogin().equals(loginGerente) && gerente.getSenha().equals(senhaGerente)) {
                gerenteAutenticado = gerente;
                break;
            }
        }

        if (gerenteAutenticado != null) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new GerenteGUI(listaFuncionarios).exibir();
                }
            });
        } else {
            JOptionPane.showMessageDialog(null, "Login ou senha de gerente incorretos. Acesso negado.");
        }
    }

    private void encerrarPrograma() {
        // Fechar a conexão com o banco de dados ao encerrar o programa
        conexaoBD.closeResources(null, null, null);
        System.out.println("Conexão com o banco de dados fechada com sucesso.");
        dispose();
    }

    public void exibir() {
        setVisible(true);
    }

    private static List<Associado> criarListaAssociados() {
        List<Associado> listaAssociados = new ArrayList<>();

        Associado associado1 = new Associado("Associado 1", "Rua A, 1", "(45) 99999-1111", "associado1@clube.com", "a1",
                "a1", 1, "a");
        listaAssociados.add(associado1);

        Associado associado2 = new Associado("Associado 2", "Rua A, 1", "(45) 99999-1111", "associado2@clube.com", "a2",
                "a2", 1, "a");
        listaAssociados.add(associado2);

        Associado associado3 = new Associado("Associado 3", "Rua A, 1", "(45) 99999-1111", "associado3@clube.com", "a3",
                "a3", 1, "a");
        listaAssociados.add(associado3);

        Associado associado4 = new Associado("Associado 4", "Rua A, 1", "(45) 99999-1111", "associado4@clube.com", "a4",
                "a4", 1, "a");
        listaAssociados.add(associado4);

        Associado associado5 = new Associado("Associado 5", "Rua A, 1", "(45) 99999-1111", "associado5@clube.com", "a5",
                "a5", 1, "a");
        listaAssociados.add(associado5);

        return listaAssociados;
    }

    private static List<Funcionario> criarListaFuncionarios() {
        List<Funcionario> listaFuncionarios = new ArrayList<>();

        Funcionario funcionario1 = new Funcionario("Funcionario 1", "Rua B, 2", "(45) 99999-2222",
                "funcionario1@clube.com", "f1", "f1", "Cadastro", " R$ 1.200,00");
        funcionario1.setPermissoesCompletas(true);
        listaFuncionarios.add(funcionario1);

        Funcionario funcionario2 = new Funcionario("Funcionario 2", "Rua B, 2", "(45) 99999-2222",
                "funcionario2@clube.com", "f2", "f2", "Lanchonete", " R$ 1.200,00");
        funcionario2.setPermissoesCompletas(false);
        listaFuncionarios.add(funcionario2);

        return listaFuncionarios;
    }

    private static List<Gerente> criarListaGerentes() {
        List<Gerente> listaGerentes = new ArrayList<>();

        Gerente gerente1 = new Gerente("Gerente 1", "Rua C, 3", "(45) 99999-3333", "gerente1@clube.com", "g1", "g1",
                "R$ 2.400,00");
        listaGerentes.add(gerente1);

        return listaGerentes;
    }

    private static List<Atividade> criarListaAtividades() {
        List<Atividade> listaAtividades = new ArrayList<>();

        Atividade atividade1 = new Atividade("Natacao", "Natacao para todos", "3 a 65 anos", "Todos", "Turma 1",
                "07 as 08, | 14 as 15 | 18 as 19", "Professora Flavia");
        listaAtividades.add(0, atividade1);

        return listaAtividades;
    }

    public static void main(String[] args) {
        ConexaoBD conexaoBD = new ConexaoBD();

        List<Associado> listaAssociados = criarListaAssociados();
        List<Funcionario> listaFuncionarios = criarListaFuncionarios();
        List<Gerente> listaGerentes = criarListaGerentes();
        List<Atividade> listaAtividades = criarListaAtividades();

        if (listaAssociados != null && listaFuncionarios != null && listaGerentes != null && listaAtividades != null) {
            // Cria e exibe a interface gráfica do menu inicial
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    conexaoBD.testarConexao();
                    MainGUI mainGui = new MainGUI(listaAssociados, listaFuncionarios, listaGerentes, listaAtividades, conexaoBD);
                    mainGui.exibir();
                }
            });
        } else {
            System.out.println("Uma ou mais listas estão vazias.");
        }
    }
}