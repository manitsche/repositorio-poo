package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import model.Associado;

public class CadastroAssociadoGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private List<Associado> listaAssociados;

    public CadastroAssociadoGUI(List<Associado> listaAssociados) {
        this.listaAssociados = listaAssociados;

        // Configurações da janela
        setTitle("Cadastro de Associado");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Layout principal
        setLayout(new GridLayout(10, 2));  // Ajustado o número de linhas para 10

        // Campos de texto
        add(new JLabel("Nome do associado:"));
        JTextField nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Endereço do associado:"));
        JTextField enderecoField = new JTextField();
        add(enderecoField);

        add(new JLabel("Telefone do associado:"));
        JTextField telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("E-mail do associado:"));
        JTextField emailField = new JTextField();
        add(emailField);

        add(new JLabel("Login do associado:"));
        JTextField loginField = new JTextField();
        add(loginField);

        add(new JLabel("Senha do associado:"));
        JPasswordField senhaField = new JPasswordField();
        add(senhaField);

        add(new JLabel("Número de dependentes:"));
        JTextField dependentesField = new JTextField();
        add(dependentesField);

        add(new JLabel("Dados de pagamento:"));
        JTextField dadosPagamentoField = new JTextField();
        add(dadosPagamentoField);

        // Botão para cadastrar associado
        JButton cadastrarButton = new JButton("Cadastrar Associado");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarAssociado(nomeField.getText(), enderecoField.getText(), telefoneField.getText(),
                        emailField.getText(), loginField.getText(), new String(senhaField.getPassword()),
                        Integer.parseInt(dependentesField.getText()), dadosPagamentoField.getText());

                // Limpar campos após o cadastro
                nomeField.setText("");
                enderecoField.setText("");
                telefoneField.setText("");
                emailField.setText("");
                loginField.setText("");
                senhaField.setText("");
                dependentesField.setText("");
                dadosPagamentoField.setText("");
            }
        });
        add(cadastrarButton);

        // Botão para fechar a janela
        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarAssociado(String nome, String endereco, String telefone, String email, String login, String senha, int dependentes, String dadosPagamento) {
        
    	List<Associado> listaAssociados = criarListaAssociados();
    	
    	int nextId = 1;
        if (!listaAssociados.isEmpty()) {
            nextId = listaAssociados.get(listaAssociados.size() - 1).getIdassociado() + 1;
        }

        Associado novoAssociado = new Associado(nome, endereco, telefone, email, login, senha, dependentes, dadosPagamento);
        listaAssociados.add(novoAssociado);
        JOptionPane.showMessageDialog(null, "Associado cadastrado com sucesso!");
        voltarAoMenuAssociado();
    }

    public void exibir() {
        setVisible(true);
    }
    
    private static List<Associado> criarListaAssociados() {
        List<Associado> listaAssociados = new ArrayList<>();

        Associado associado1 = new Associado("Associado 1", "Rua A, 1", "(45) 99999-1111", "associado1@clube.com", "a1", "a1", 1, "a");
        listaAssociados.add(associado1);

        Associado associado2 = new Associado("Associado 2", "Rua A, 1", "(45) 99999-1111", "associado2@clube.com", "a2", "a2", 1, "a");
        listaAssociados.add(associado2);

        Associado associado3 = new Associado("Associado 3", "Rua A, 1", "(45) 99999-1111", "associado3@clube.com", "a3", "a3", 1, "a");
        listaAssociados.add(associado3);

        Associado associado4 = new Associado("Associado 4", "Rua A, 1", "(45) 99999-1111", "associado4@clube.com", "a4", "a4", 1, "a");
        listaAssociados.add(associado4);

        Associado associado5 = new Associado("Associado 5", "Rua A, 1", "(45) 99999-1111", "associado5@clube.com", "a5", "a5", 1, "a");
        listaAssociados.add(associado5);

        return listaAssociados;
    }
    
    private void voltarAoMenuAssociado() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AssociadoGUI().exibir();
            }
        });
    }
}