package view;

import javax.swing.*;
import model.Funcionario;
import model.Notificacao;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class GerenteGUI extends JFrame {

    private static final long serialVersionUID = -4647562561784234943L;
    private List<Funcionario> listaFuncionarios;

    public GerenteGUI(List<Funcionario> listaFuncionarios) {
        // Configurações da janela
        setTitle("Menu Gerente");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Layout principal
        setLayout(new GridLayout(6, 1));

        // Botão para cadastrar novo funcionário
        JButton cadastrarFuncionarioButton = new JButton("Cadastrar novo funcionário");
        cadastrarFuncionarioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	dispose();
                CadastroFuncionarioGUI cadastroFuncionarioGUI = new CadastroFuncionarioGUI(listaFuncionarios);
                cadastroFuncionarioGUI.exibir();
            	 
            }
        });
        add(cadastrarFuncionarioButton);

        // Botão para definir permissões de acesso a um funcionário
        JButton definirPermissoesButton = new JButton("Definir permissões de acesso a um funcionário");
        definirPermissoesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para definir permissões
                JOptionPane.showMessageDialog(null, "Funcionalidade não implementada ainda.");
            }
        });
        add(definirPermissoesButton);

        // Botão para visualizar resumos de funcionários
        JButton visualizarResumosButton = new JButton("Visualizar resumos de funcionários");
        visualizarResumosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para visualizar resumos
                JOptionPane.showMessageDialog(null, "Funcionalidade não implementada ainda.");
            }
        });
        add(visualizarResumosButton);

        // Botão para cadastrar nova turma em atividade
        JButton cadastrarTurmaButton = new JButton("Cadastrar nova turma em atividade");
        cadastrarTurmaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para cadastrar nova turma
                JOptionPane.showMessageDialog(null, "Funcionalidade não implementada ainda.");
            }
        });
        add(cadastrarTurmaButton);

        // Botão para configurar notificações
        JButton configurarNotificacoesButton = new JButton("Configurar notificações");
        configurarNotificacoesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para configurar notificações
                Notificacao.configurarNotificacoes(null);
            }
        });
        add(configurarNotificacoesButton);

        // Botão para voltar ao menu anterior
        JButton voltarButton = new JButton("Voltar ao menu anterior");
        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para voltar ao menu anterior
                dispose(); // Fecha a janela atual
            }
        });
        add(voltarButton);
    }

    public void exibir() {
        setVisible(true);
    }
}
