package view;

import javax.swing.*;
import model.Associado;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import model.Atividade;
import model.Atividade;

public class FuncionarioGUI extends JFrame {
    
	private static final long serialVersionUID = 6543003619980991398L;
    private List<Associado> listaAssociados;
    private List<Atividade> listaAtividades;
    
    
    public FuncionarioGUI(List<Associado> listaAssociados, List<Atividade> listaAtividades) {
        // Configurações da janela do funcionário
        setTitle("Menu do Funcionário");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Layout principal
        setLayout(new GridLayout(10, 1));

        // Adiciona os botões ao painel
        adicionarBotao("Cadastrar novo associado", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                CadastroAssociadoGUI cadastroAssociadoGUI = new CadastroAssociadoGUI(listaAssociados);
                cadastroAssociadoGUI.exibir();
                dispose();
            }
        });

        adicionarBotao("Visualizar listagem de associados", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para visualizar listagem de associados
                JOptionPane.showMessageDialog(null, "Visualizar listagem de associados selecionado");
            }
        });

        adicionarBotao("Atualizar dados cadastrais de associados", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para atualizar dados cadastrais de associados
                JOptionPane.showMessageDialog(null, "Atualizar dados cadastrais de associados selecionado");
            }
        });

        adicionarBotao("Criar resumo pessoal", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para criar resumo pessoal
                JOptionPane.showMessageDialog(null, "Criar resumo pessoal selecionado");
            }
        });

        adicionarBotao("Cadastrar nova atividade", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	CadastroAtividadeGUI cadastroAtividadeGUI = new CadastroAtividadeGUI(listaAtividades);
                cadastroAtividadeGUI.exibir();
                dispose();
            }
        });

        adicionarBotao("Visualizar atividades cadastradas", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para visualizar atividades cadastradas
                JOptionPane.showMessageDialog(null, "Visualizar atividades cadastradas selecionado");
            }
        });

        adicionarBotao("Cadastrar associado em atividade", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para cadastrar associado em atividade
                JOptionPane.showMessageDialog(null, "Cadastrar associado em atividade selecionado");
            }
        });

        adicionarBotao("Registrar falta de associado em atividade", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para registrar falta de associado em atividade
                JOptionPane.showMessageDialog(null, "Registrar falta de associado em atividade selecionado");
            }
        });

        adicionarBotao("Configurar notificações", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para configurar notificações
                JOptionPane.showMessageDialog(null, "Configurar notificações selecionado");
            }
        });

        adicionarBotao("Voltar ao menu anterior", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para voltar ao menu anterior
                JOptionPane.showMessageDialog(null, "Voltar ao menu anterior selecionado");
            }
        });
    }

    public void exibir() {
        setVisible(true);
    }
    
    private void adicionarBotao(String texto, ActionListener actionListener) {
        JButton button = new JButton(texto);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Fechar a janela atual ao clicar em um botão
                actionListener.actionPerformed(e);
            }
        });
        add(button);
    }
}