package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import model.Associado;
import model.Atividade;
import model.Funcionario;

public class CadastroFuncionarioGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private List<Funcionario> listaFuncionarios;
    private List<Associado> listaAssociados;
    private List<Atividade> listaAtividades;

    public CadastroFuncionarioGUI(List<Funcionario> listaFuncionarios) {
        this.listaFuncionarios = listaFuncionarios;

        setTitle("Cadastro de Funcionário");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(9, 2));

        add(new JLabel("Nome do funcionário:"));
        JTextField nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Endereço do funcionário:"));
        JTextField enderecoField = new JTextField();
        add(enderecoField);

        add(new JLabel("Telefone do funcionário:"));
        JTextField telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("E-mail do funcionário:"));
        JTextField emailField = new JTextField();
        add(emailField);

        add(new JLabel("Cargo do funcionário:"));
        JTextField cargoField = new JTextField();
        add(cargoField);

        add(new JLabel("Salário do funcionário:"));
        JTextField salarioField = new JTextField();
        add(salarioField);

        add(new JLabel("Login do funcionário:"));
        JTextField loginField = new JTextField();
        add(loginField);

        add(new JLabel("Senha do funcionário:"));
        JPasswordField senhaField = new JPasswordField();
        add(senhaField);

        JButton cadastrarButton = new JButton("Cadastrar Funcionário");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarFuncionario(nomeField.getText(), enderecoField.getText(), telefoneField.getText(),
                        emailField.getText(), cargoField.getText(), salarioField.getText(), loginField.getText(),
                        new String(senhaField.getPassword()));

                // Limpar campos após o cadastro
                nomeField.setText("");
                enderecoField.setText("");
                telefoneField.setText("");
                emailField.setText("");
                cargoField.setText("");
                salarioField.setText("");
                loginField.setText("");
                senhaField.setText("");
            }
        });
        add(cadastrarButton);

        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarFuncionario(String nome, String endereco, String telefone, String email, String cargo,
            String salario, String login, String senha) {

        int nextId = 1;
        if (!listaFuncionarios.isEmpty()) {
            nextId = listaFuncionarios.get(listaFuncionarios.size() - 1).getIdfuncionario() + 1;
        }

        Funcionario novoFuncionario = new Funcionario(nome, endereco, telefone, email, login, senha, cargo, salario);
        listaFuncionarios.add(novoFuncionario);
        JOptionPane.showMessageDialog(null, "Funcionário cadastrado com sucesso!");
        voltarAoMenuFuncionario();
    }
    
    private static List<Funcionario> criarListaFuncionarios() {
        List<Funcionario> listaFuncionarios = new ArrayList<>();
    
        Funcionario funcionario1 = new Funcionario("Funcionario 1", "Rua B, 2", "(45) 99999-2222", "funcionario1@clube.com", "f1", "f1", "Cadastro", " R$ 1.200,00");
        funcionario1.setPermissoesCompletas(true);
        listaFuncionarios.add(funcionario1);
        
        Funcionario funcionario2 = new Funcionario("Funcionario 2", "Rua B, 2", "(45) 99999-2222", "funcionario2@clube.com", "f2", "f2", "Lanchonete", " R$ 1.200,00");
        funcionario2.setPermissoesCompletas(false);
        listaFuncionarios.add(funcionario2);
        
        return listaFuncionarios;
    }

    public void exibir() {
        setVisible(true);
    }
    
    private void voltarAoMenuFuncionario() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FuncionarioGUI(listaAssociados, listaAtividades).exibir();
            }
        });
    }

}