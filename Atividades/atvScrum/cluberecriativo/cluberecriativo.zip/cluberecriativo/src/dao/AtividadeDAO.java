package dao;

import model.Atividade;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AtividadeDAO {

    private ConexaoBD conexaoBD;

    public AtividadeDAO() {
        this.conexaoBD = new ConexaoBD();
    }

    public void cadastrarAtividade(Atividade atividade) throws ExceptionDAO {
        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = conexaoBD.getConnection();
            String sql = "INSERT INTO ATIVIDADE (nome, descricao, faixaetaria, niveishabilidade, turma, horario, instrutor) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, atividade.getNome());
            stmt.setString(2, atividade.getDescricao());
            stmt.setString(3, atividade.getFaixaEtaria());
            stmt.setString(4, atividade.getNiveisHabilidade());
            stmt.setString(5, atividade.getTurmasAsString());
            stmt.setString(6, atividade.getHorario());
            stmt.setString(7, atividade.getInstrutores());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar atividade: " + e.getMessage());
        } finally {
            conexaoBD.closeResources(conexao, stmt, null);
        }
    }
}
