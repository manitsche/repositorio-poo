package dao;

import model.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FuncionarioDAO {

    private ConexaoBD conexaoBD;

    public FuncionarioDAO() {
        this.conexaoBD = new ConexaoBD();
    }

    public void cadastrarFuncionario(Funcionario funcionario) throws ExceptionDAO {
        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = conexaoBD.getConnection();
            String sql = "INSERT INTO FUNCIONARIO (nome, endereco, telefone, email, login, senha, cargo, salario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getEndereco());
            stmt.setString(3, funcionario.getTelefone());
            stmt.setString(4, funcionario.getEmail());
            stmt.setString(5, funcionario.getLogin());
            stmt.setString(6, funcionario.getSenha());
            stmt.setString(7, funcionario.getCargo());
            stmt.setString(8, funcionario.getSalario());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar funcionário: " + e.getMessage());
        } finally {
            conexaoBD.closeResources(conexao, stmt, null);
        }
    }
}