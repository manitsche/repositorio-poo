package dao;

import model.Associado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AssociadoDAO {

    private ConexaoBD conexaoBD;

    public AssociadoDAO() {
        this.conexaoBD = new ConexaoBD();
    }

    public void cadastrarAssociado(Associado associado) throws ExceptionDAO {
        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            // Obtém a conexão do pool de conexões
            conexao = conexaoBD.getConnection();
            
            // Desativa o autocommit para gerenciar a transação manualmente
            conexao.setAutoCommit(false);

            String sql = "INSERT INTO ASSOCIADO (nome, endereco, telefone, email, login, senha, dependentes, dadospagamento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conexao.prepareStatement(sql);

            // Define os parâmetros da instrução SQL
            stmt.setString(1, associado.getNome());
            stmt.setString(2, associado.getEndereco());
            stmt.setString(3, associado.getTelefone());
            stmt.setString(4, associado.getEmail());
            stmt.setString(5, associado.getLogin());
            stmt.setString(6, associado.getSenha());
            stmt.setInt(7, associado.getDependentes());
            stmt.setString(8, associado.getDadosPagamento());

            // Executa a instrução SQL
            stmt.executeUpdate();

            // Confirma a transação
            conexao.commit();
        } catch (SQLException e) {
            // Se ocorrer um erro, faz rollback da transação
            try {
                if (conexao != null) {
                    conexao.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            throw new ExceptionDAO("Erro ao cadastrar associado: " + e.getMessage());
        } finally {
            // Sempre fecha a conexão e o statement
            conexaoBD.closeResources(conexao, stmt, null);
        }
    }
}