package controller;

import model.Atividade;
import dao.AtividadeDAO;
import dao.ExceptionDAO;

public class AtividadeController {

    private AtividadeDAO atividadeDAO;

    public AtividadeController() {
        this.atividadeDAO = new AtividadeDAO();
    }

    public void cadastrarAtividade(String nome, String descricao, String faixaEtaria, String niveisHabilidade, String[] turmas, String horario, String instrutores) {
        try {
            // Convertendo o vetor para uma String delimitada por ","
            String turmasString = String.join(",", turmas);

            Atividade atividade = new Atividade(nome, descricao, faixaEtaria, niveisHabilidade, turmasString, horario, instrutores);
            atividadeDAO.cadastrarAtividade(atividade);
            System.out.println("Atividade cadastrada com sucesso!");
        } catch (ExceptionDAO e) {
            System.out.println("Erro ao cadastrar atividade: " + e.getMessage());
        }
    }
}