package controller;

import model.Funcionario;
import dao.FuncionarioDAO;
import dao.ExceptionDAO;

public class FuncionarioController {

    private FuncionarioDAO funcionarioDAO;

    public FuncionarioController() {
        this.funcionarioDAO = new FuncionarioDAO();
    }

    public void cadastrarFuncionario(String nome, String endereco, String telefone, String email, String login, String senha, String cargo, String salario) {
        try {
            Funcionario funcionario = new Funcionario(nome, endereco, telefone, email, login, senha, cargo, salario);
            funcionarioDAO.cadastrarFuncionario(funcionario);
            System.out.println("Funcionario cadastrado com sucesso!");
        } catch (ExceptionDAO e) {
            System.out.println("Erro ao cadastrar funcionário: " + e.getMessage());
        }
    }
}
