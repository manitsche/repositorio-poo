package controller;

import model.Associado;
import dao.AssociadoDAO;
import dao.ExceptionDAO;

public class AssociadoController {

    private AssociadoDAO associadoDAO;

    public AssociadoController() {
        this.associadoDAO = new AssociadoDAO();
    }

    public void cadastrarAssociado(String nome, String endereco, String telefone, String email, String login, String senha, int dependentes, String dadosPagamento) {
        try {
            Associado associado = new Associado(nome, endereco, telefone, email, login, senha, dependentes, dadosPagamento);
            associadoDAO.cadastrarAssociado(associado);
            System.out.println("Associado cadastrado com sucesso!");
        } catch (ExceptionDAO e) {
            System.out.println("Erro ao cadastrar associado: " + e.getMessage());
        }
    }
}