package view;

import controller.FuncionarioController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroFuncionarioGUI extends JFrame {

    private static final long serialVersionUID = 1308930350867381874L;
    private JTextField nomeField, enderecoField, telefoneField, emailField, loginField, senhaField, cargoField, salarioField;
    private FuncionarioController funcionarioController;

    public CadastroFuncionarioGUI(FuncionarioController funcionarioController) {
        this.funcionarioController = funcionarioController;

        setTitle("Cadastro de Funcionário");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(9, 2, 5, 5)); // 9 linhas, 2 colunas, espaçamento horizontal e vertical de 5 pixels

        add(new JLabel("Nome:"));
        nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Endereço:"));
        enderecoField = new JTextField();
        add(enderecoField);

        add(new JLabel("Telefone:"));
        telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("E-mail:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Login:"));
        loginField = new JTextField();
        add(loginField);

        add(new JLabel("Senha:"));
        senhaField = new JTextField();
        add(senhaField);

        add(new JLabel("Cargo:"));
        cargoField = new JTextField();
        add(cargoField);

        add(new JLabel("Salário:"));
        salarioField = new JTextField();
        add(salarioField);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarFuncionario();
            }
        });
        add(cadastrarButton);

        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarFuncionario() {
        String nome = nomeField.getText();
        String endereco = enderecoField.getText();
        String telefone = telefoneField.getText();
        String email = emailField.getText();
        String login = loginField.getText();
        String senha = senhaField.getText();
        String cargo = cargoField.getText();
        String salario = salarioField.getText();

        funcionarioController.cadastrarFuncionario(nome, endereco, telefone, email, login, senha, cargo, salario);
    }

    public void exibir() {
        setVisible(true);
    }
}
