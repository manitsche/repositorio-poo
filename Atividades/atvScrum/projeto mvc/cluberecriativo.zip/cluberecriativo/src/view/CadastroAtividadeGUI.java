package view;

import controller.AtividadeController;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroAtividadeGUI extends JFrame {

	private static final long serialVersionUID = -2476009338216713893L;
	private JTextField nomeField, descricaoField, faixaEtariaField, niveisHabilidadeField, turmasField, horarioField, instrutoresField;
    private AtividadeController atividadeController;

    public CadastroAtividadeGUI(AtividadeController atividadeController) {
        this.atividadeController = atividadeController;

        // Configurações da janela
        setTitle("Cadastro de Atividade");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Layout principal
        setLayout(new GridLayout(8, 2));

        // Adiciona campos de entrada
        add(new JLabel("Nome:"));
        nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Descrição:"));
        descricaoField = new JTextField();
        add(descricaoField);

        add(new JLabel("Faixa Etária:"));
        faixaEtariaField = new JTextField();
        add(faixaEtariaField);

        add(new JLabel("Níveis de Habilidade:"));
        niveisHabilidadeField = new JTextField();
        add(niveisHabilidadeField);

        add(new JLabel("Turmas (separadas por vírgula):"));
        turmasField = new JTextField();
        add(turmasField);

        add(new JLabel("Horário:"));
        horarioField = new JTextField();
        add(horarioField);

        add(new JLabel("Instrutores:"));
        instrutoresField = new JTextField();
        add(instrutoresField);

        // Botão de cadastro
        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarAtividade();
            }
        });
        add(cadastrarButton);

        // Botão de fechar
        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarAtividade() {
        // Obtém os dados dos campos de entrada
        String nome = nomeField.getText();
        String descricao = descricaoField.getText();
        String faixaEtaria = faixaEtariaField.getText();
        String niveisHabilidade = niveisHabilidadeField.getText();
        String turmas = turmasField.getText();
        String horario = horarioField.getText();
        String instrutores = instrutoresField.getText();

        // Chama o método cadastrarAtividade do AtividadeController
        atividadeController.cadastrarAtividade(nome, descricao, faixaEtaria, niveisHabilidade, turmas.split(","), horario, instrutores);

        // Limpa os campos após cadastrar
        limparCampos();
    }

    private void limparCampos() {
        nomeField.setText("");
        descricaoField.setText("");
        faixaEtariaField.setText("");
        niveisHabilidadeField.setText("");
        turmasField.setText("");
        horarioField.setText("");
        instrutoresField.setText("");
    }

    public void exibir() {
        setVisible(true);
    }
}