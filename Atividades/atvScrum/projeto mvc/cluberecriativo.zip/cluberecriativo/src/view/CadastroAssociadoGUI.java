package view;

import controller.AssociadoController;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroAssociadoGUI extends JFrame {

	private static final long serialVersionUID = 1308930350867381874L;
	private JTextField nomeField, enderecoField, telefoneField, emailField, loginField, senhaField, dependentesField, dadosPagamentoField;
    private AssociadoController associadoController;

    public CadastroAssociadoGUI(AssociadoController associadoController) {
        this.associadoController = associadoController;

        // Configurações da janela
        setTitle("Cadastro de Associado");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        

        // Layout principal
        setLayout(new GridLayout(9, 2));

        // Adiciona campos de entrada
        add(new JLabel("Nome:"));
        nomeField = new JTextField();
        add(nomeField);

        add(new JLabel("Endereço:"));
        enderecoField = new JTextField();
        add(enderecoField);

        add(new JLabel("Telefone:"));
        telefoneField = new JTextField();
        add(telefoneField);

        add(new JLabel("E-mail:"));
        emailField = new JTextField();
        add(emailField);

        add(new JLabel("Login:"));
        loginField = new JTextField();
        add(loginField);

        add(new JLabel("Senha:"));
        senhaField = new JTextField();
        add(senhaField);

        add(new JLabel("Dependentes:"));
        dependentesField = new JTextField();
        add(dependentesField);

        add(new JLabel("Dados de Pagamento:"));
        dadosPagamentoField = new JTextField();
        add(dadosPagamentoField);

        // Botão de cadastro
        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarAssociado();
            }
        });
        add(cadastrarButton);

        // Botão de fechar
        JButton fecharButton = new JButton("Fechar");
        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        add(fecharButton);
    }

    private void cadastrarAssociado() {
        // Obtém os dados dos campos de entrada
        String nome = nomeField.getText();
        String endereco = enderecoField.getText();
        String telefone = telefoneField.getText();
        String email = emailField.getText();
        String login = loginField.getText();
        String senha = senhaField.getText();
        int dependentes = Integer.parseInt(dependentesField.getText());
        String dadosPagamento = dadosPagamentoField.getText();

        // Chama o método cadastrarAssociado do AssociadoController
        associadoController.cadastrarAssociado(nome, endereco, telefone, email, login, senha, dependentes, dadosPagamento);
    }

    public void exibir() {
    	setVisible(true);
    }
}