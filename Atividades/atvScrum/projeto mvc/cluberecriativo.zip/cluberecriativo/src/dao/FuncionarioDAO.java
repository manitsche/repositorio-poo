package dao;

import model.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FuncionarioDAO {

    private ConexaoBD conexaoBD;

    public FuncionarioDAO() {
        this.conexaoBD = new ConexaoBD();
    }

    public void cadastrarFuncionario(Funcionario funcionario) throws ExceptionDAO {
        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            // Obtém a conexão do pool de conexões
            conexao = conexaoBD.getConnection();
            
            // Desativa o autocommit para gerenciar a transação manualmente
            conexao.setAutoCommit(false);

            String sql = "INSERT INTO FUNCIONARIO (nome, endereco, telefone, email, login, senha, cargo, salario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conexao.prepareStatement(sql);

            // Define os parâmetros da instrução SQL
            stmt.setString(1, funcionario.getNome());
            stmt.setString(2, funcionario.getEndereco());
            stmt.setString(3, funcionario.getTelefone());
            stmt.setString(4, funcionario.getEmail());
            stmt.setString(5, funcionario.getLogin());
            stmt.setString(6, funcionario.getSenha());
            stmt.setString(7, funcionario.getCargo());
            stmt.setString(8, funcionario.getSalario());

            // Executa a instrução SQL
            stmt.executeUpdate();

            // Confirma a transação
            conexao.commit();
        } catch (SQLException e) {
            // Se ocorrer um erro, faz rollback da transação
            try {
                if (conexao != null) {
                    conexao.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            throw new ExceptionDAO("Erro ao cadastrar funcionario: " + e.getMessage());
        } finally {
            // Sempre fecha a conexão e o statement
            conexaoBD.closeResources(conexao, stmt, null);
        }
    }
}
