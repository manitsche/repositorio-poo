package dao;

import model.Atividade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AtividadeDAO {

    private ConexaoBD conexaoBD;

    public AtividadeDAO() {
        this.conexaoBD = new ConexaoBD();
    }

    public void cadastrarAtividade(Atividade atividade) throws ExceptionDAO {
        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            // Obtém a conexão do pool de conexões
            conexao = conexaoBD.getConnection();

            // Desativa o autocommit para gerenciar a transação manualmente
            conexao.setAutoCommit(false);

            String sql = "INSERT INTO ATIVIDADE (nome, descricao, faixaetaria, niveishabilidade, turma, horario, instrutor) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conexao.prepareStatement(sql);

            // Define os parâmetros da instrução SQL
            stmt.setString(1, atividade.getNome());
            stmt.setString(2, atividade.getDescricao());
            stmt.setString(3, atividade.getFaixaEtaria());
            stmt.setString(4, atividade.getNiveisHabilidade());
            stmt.setString(5, String.join(",", atividade.getTurmas())); // Convertendo o vetor para uma String
            stmt.setString(6, atividade.getHorario());
            stmt.setString(7, atividade.getInstrutores());

            // Executa a instrução SQL
            stmt.executeUpdate();

            // Confirma a transação
            conexao.commit();
        } catch (SQLException e) {
            // Se ocorrer um erro, faz rollback da transação
            try {
                if (conexao != null) {
                    conexao.rollback();
                }
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            throw new ExceptionDAO("Erro ao cadastrar atividade: " + e.getMessage());
        } finally {
            // Sempre fecha a conexão e o statement
            conexaoBD.closeResources(conexao, stmt, null);
        }
    }
}