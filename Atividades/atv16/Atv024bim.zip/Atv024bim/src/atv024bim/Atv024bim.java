package atv024bim;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Atv024bim {

	public static void main(String[] args) {
		
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(8, 2));

        JLabel nomeLabel = new JLabel("Nome:");
        JTextField nomeField = new JTextField();

        JLabel enderecoLabel = new JLabel("Endereço:");
        JTextField enderecoField = new JTextField();

        JLabel telefoneLabel = new JLabel("Telefone:");
        JFormattedTextField telefoneField = new JFormattedTextField(createFormatter("##########"));
        telefoneField.setColumns(15);

        JLabel tipoSanguineoLabel = new JLabel("Tipo Sanguíneo:");
        String[] tiposSanguineos = {"A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"};
        JComboBox<String> tipoSanguineoComboBox = new JComboBox<>(tiposSanguineos);

        JLabel cursoAtualLabel = new JLabel("Curso Atual:");
        String[] cursos = {"Engenharia", "Medicina", "Direito", "Ciência da Computação", "Administração"};
        JComboBox<String> cursoAtualComboBox = new JComboBox<>(cursos);

        JLabel contatoEmergenciaNomeLabel = new JLabel("Nome do Contato de Emergência:");
        JTextField contatoEmergenciaNomeField = new JTextField();

        JLabel contatoEmergenciaTelefoneLabel = new JLabel("Telefone do Contato de Emergência:");
        JFormattedTextField contatoEmergenciaTelefoneField = new JFormattedTextField(createFormatter("##########"));
        contatoEmergenciaTelefoneField.setColumns(15);

        JButton salvarButton = new JButton("Salvar");
        JButton cancelarButton = new JButton("Cancelar");

        frame.add(nomeLabel);
        frame.add(nomeField);
        frame.add(enderecoLabel);
        frame.add(enderecoField);
        frame.add(telefoneLabel);
        frame.add(telefoneField);
        frame.add(tipoSanguineoLabel);
        frame.add(tipoSanguineoComboBox);
        frame.add(cursoAtualLabel);
        frame.add(cursoAtualComboBox);
        frame.add(contatoEmergenciaNomeLabel);
        frame.add(contatoEmergenciaNomeField);
        frame.add(contatoEmergenciaTelefoneLabel);
        frame.add(contatoEmergenciaTelefoneField);
        frame.add(salvarButton);
        frame.add(cancelarButton);

        salvarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = nomeField.getText();
                String endereco = enderecoField.getText();
                String telefone = telefoneField.getText();
                String tipoSanguineo = (String) tipoSanguineoComboBox.getSelectedItem();
                String cursoAtual = (String) cursoAtualComboBox.getSelectedItem();
                String contatoEmergenciaNome = contatoEmergenciaNomeField.getText();
                String contatoEmergenciaTelefone = contatoEmergenciaTelefoneField.getText();

                JOptionPane.showMessageDialog(frame, "Dados Salvos:\nNome: " + nome + "\nEndereço: " + endereco + "\nTelefone: " + telefone + "\nTipo Sanguíneo: " + tipoSanguineo + "\nCurso Atual: " + cursoAtual + "\nContato de Emergência: " + contatoEmergenciaNome + ", " + contatoEmergenciaTelefone);
            }
        });

        cancelarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        frame.setVisible(true);
    }

    private static MaskFormatter createFormatter(String s) {
        MaskFormatter formatter = null;
        try {
            formatter = new MaskFormatter(s);
        } catch (java.text.ParseException exc) {
            System.err.println("Erro na formatação: " + exc.getMessage());
        }
        return formatter;

	}
}